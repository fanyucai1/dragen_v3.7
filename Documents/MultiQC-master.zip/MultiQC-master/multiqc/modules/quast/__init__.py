from __future__ import absolute_import

from .quast import MultiqcModule
