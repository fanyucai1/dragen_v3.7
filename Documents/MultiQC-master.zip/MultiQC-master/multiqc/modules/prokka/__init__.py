from __future__ import absolute_import
from .prokka import MultiqcModule
