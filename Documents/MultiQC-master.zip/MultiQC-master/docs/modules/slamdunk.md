---
Name: Slamdunk
URL: http://t-neumann.github.io/slamdunk/
Description: >
    Slamdunk is a tool to analyze SLAM-Seq data.
---

[Slamdunk](http://t-neumann.github.io/slamdunk/) is a tool to analyze data from the SLAM-Seq sequencing protocol.

This module should be able to parse logs from v0.2.2-dev onwards.