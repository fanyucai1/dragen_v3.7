---
Name: Fgbio
URL: http://fulcrumgenomics.github.io/fgbio/tools/latest/
Description: >
    Fgbio can be used for processing and evaluating data containing UMIs
---

The fgbio MultiQC module currently supports tool the following outputs:

* [GroupReadsByUmi](http://fulcrumgenomics.github.io/fgbio/tools/latest/GroupReadsByUmi.html/)
* [ErrorRateByReadPosition](http://fulcrumgenomics.github.io/fgbio/tools/latest/ErrorRateByReadPosition.html/)
